Free Download Source Code "Advance Inventory Management System"

FIRST Download

1.XAMPP

2."TEXT EDITOR" NOTEPAD++ OR SUBLIME TEXT 3 / ETC.

3"inventory-management-system"

4. Download the zip file/ download winrar

5. Extract the file and copy "inventory-management-system" folder

6.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

7. Open PHPMyAdmin (http://localhost/phpmyadmin)

8. Create a database with name shop_inventory

6. Import shop_inventory.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/inventory-management-system


**LOGIN DETAILS** 

username: admin
password: admin

****** https:1sourcecodr.blogspot.com ******
Subcribe my You tube Channel **** 1 Source code ****